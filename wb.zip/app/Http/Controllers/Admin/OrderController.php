<?php
/**
 * Created by PhpStorm.
 * User: echo
 * Date: 17-8-22
 * Time: 下午9:42
 */
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\ControllerREST;
use App\Models\AgentOrderForm;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends ControllerREST
{
    protected $model = 'App\Models\AgentOrderForm';

    protected $controller = 'admin.order';

    /**
     * 设置快递信息
     * @param Request $request
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\View\View
     */
    public function post(Request $request, $id) {
        $order = $this->iModel->find($id);
        if($order->status == AgentOrderForm::STATUS_WAIT_POST) {
            if($request->isMethod('POST')) {
                DB::transaction(function() use($order, $request) {
                    $order->update($request->all());
                    $order->status = AgentOrderForm::STATUS_WAIT_RECEIVE;
                    $order->save();
                });
                return redirect()->route('staff.order.lists');
            }
            return view('admin.order.post', ['order'=> $order]);
        }
        return redirect()->route('staff.order.lists');
    }

    /**
     * 审核通过订单
     * @param Request $request
     * @param $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function check(Request $request, $id) {
        $order = $this->iModel->find($id);
        if($order->status == AgentOrderForm::STATUS_WATI_CHECK) {
            $order->status = AgentOrderForm::STATUS_WAIT_POST;
            $order->save();
        }
        return redirect()->route('staff.order.lists');
    }
}