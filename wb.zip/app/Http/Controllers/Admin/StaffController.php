
<?php
/**
 * Created by PhpStorm.
 * User: echo
 * Date: 17-8-22
 * Time: 下午9:42
 */

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class StaffController extends Controller
{

    public function modify(Request $request) {

    }

    public function doModify(Request $request) {

    }

    public function lists(Request $request) {

    }

    public function add(Request $request) {

    }

    public function doAdd(Request $request) {

    }

    public function delete(Request $request) {

    }

}