<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Support\Facades\View;


class Controller extends BaseController {
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

//    protected $row = 1;

    protected $controller = 'index';


    protected $row = 20;
    protected $field = ['*'];

    protected $sort = [['created_at', 'desc']];

    protected $options = [];

    public function __construct(Request $request) {
        $this->row = empty($request->get('row')) ? $this->row : intval($request->get('row'));
        $this->field = empty($request->get('field')) ? $this->field : explode(',', $request->get('field'));

        $sort = $request->get('sort');
        if (!empty($sort)) {
            $sort = explode(',', $sort);
            foreach ($sort as &$s) {
                if (strpos($s, '-') !== false) {
                    $s = [substr($s, 1), 'desc'];
                } else {
                    $s = [$s, 'asc'];
                }
            }
        }
        $this->sort = empty($request->get('sort')) ? $this->sort : $sort;

        $this->options = ['sort' => $this->sort, 'row' => $this->row, 'field' => $this->field];

        View::share('controller', $this->controller);
    }

    /**
     * 返回api数据
     *
     * @param [type] $data
     * @param [type] $msg
     * @param integer $status
     * @return void
     */
    public function  apiData($data, $msg='', $status=1) {
        return response()->json([
            'status'=>$status,
            'msg' => $msg,
            'data' => $data,
        ]);
    }

    /**
     * 错误返回
     *
     * @param [type] $msg
     * @param [type] $status
     * @return void
     */
    public function apiErr($msg, $status=0) {
        return $this->apiData([], $msg, $status);
    }
}
