<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ControllerREST extends Controller {
    /**
     * 模型名
     *
     * @var [type]
     */
    protected $model;

    /**
     * 核验字段
     *
     * @var array
     */
    protected $fieldValidation=[];

    protected $updateFieldValidation = [];
    /**
     * 模型实例
     *
     * @var [type]
     */
    protected $iModel;

    /**
     * 修改视图
     *
     * @var [type]
     */
    protected $modifyView='modify';

    /**
     * 添加的视图
     *
     * @var string
     */
    protected $addView = 'add';

    /**
     * 列表的视图
     *
     * @var string
     */
    protected $listView = 'index';

    /**
     * 重定向路由别名
     *
     * @var string
     */
    protected $redirectUrlAlias = '';

    /**
     * 重定向路由参数
     * @var array
     */
    protected $redirectParams = [];

    public function __construct(Request $request) {
        parent::__construct($request);
        $this->iModel = new $this->model();
    }

    /**
     * 得到额外的变量
     *
     * @return void
     */
    public function addExternalData() {
        return [];
    }

    /**
     * 修改时添加的额外参数
     *
     * @return void
     */
    public function modifyExternalData() {
        return [];
    }

    /**
     * 显示列表时添加的额外参数
     *
     * @return void
     */
    public function listExternalData() {
        return [];
    }

    /**
     * 显示修改视图
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function modify(Request $request, $id) {
        //得到agenteUser信息
        $data = $this->iModel->find($id);
        $externalData = $this->modifyExternalData();
        return view($this->controller.'.'.$this->modifyView, array_merge(['data'=>$data], $externalData));
    }

    /**
     * 修改数据
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function doModify(Request $request, $id) {
        $item = $this->iModel->find($id);
        $this->validate($request, $this->updateFieldValidation);
        $item->update($request->all());
        // return true;
        return redirect()->route($this->redirectUrlAlias, $this->redirectParams);
    }

    /**
     * 处理额外条件
     *
     * @param [type] $conditions
     * @return void
     */
    public function parseQuery(&$conditions) {

    }

    /**
     * 显示列表
     *
     * @param Request $request
     * @return void
     */
    public function lists(Request $request) {
        $conditions = [];
        $this->parseQuery($conditions);
        $query = $this->iModel;
        if(!empty($conditions)) {
            foreach($conditions as $k => $v) {
                if(is_string($v)) {

                    $query = $this->where($k, $v);
                } else {
                    if(is_array($v)) {
                        switch(strtolower($v)) {
                            case 'in':
                                $query = $this->whereIn($k, $v[1]);
                                break;
                            case 'or':
                                $query = $this->orWhere($k, $v[1]);
                                break;
                            case 'between':
                                $query = $this->whereBetween($k, $v[1]);
                                break;
                            default:
                                $query = $this->where($k, $v[0], $v[1]);
                        }
                    }
                }
            }
        }
        if(!empty($this->sort)) {
            foreach($this->sort as $s) {
                $query = $query->orderBy($s[0], $s[1]);
            }
        }
        $data = $query->select($this->field)->paginate($this->row);
        $externalData = $this->listExternalData();
        return view($this->controller. '.'. $this->listView, array_merge(['data'=>$data], $externalData));
    }

    /**
     * 显示添加视图
     *
     * @param Request $request
     * @return void
     */
    public function add(Request $request) {
        $externalData = $this->addExternalData();
        return view($this->controller.'.'.$this->addView, $externalData);
    }

    /**
     * 添加事件
     *
     * @param Request $request
     * @return void
     */
    public function doAdd(Request $request) {
        $this->validate($request, $this->fieldValidation);
        $this->iModel->create($request->all());
        // return true;
        return redirect()->route($this->redirectUrlAlias, $this->redirectParams);
    }

    /**
     * 删除记录
     *
     * @param Request $request
     * @return void
     */
    public function delete(Request $request) {
        $id = $request->input('id');
        $data = $this->iModel->find($id);
        if(!empty($data)) {
            $data->delete();
            return $this->apiData([]);
        }
        return $this->apiErr('记录不存在');
    }
}
