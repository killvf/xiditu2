<?php

namespace App\Models;

class AgentBalanceRecord extends BaseModel
{
    //
    /**
     * 得到指定用户的余额
     * @param $id
     * @return int
     * @throws \Exception
     */
    public function amount($id) {
        $mAgent = new AgentUser();
        $agent = $mAgent->find($id);
        if(empty($agent)) {
            throw new \Exception('用户不存在');
        }
        $amountInfo = $this->where('agent_user_id', $id)->orderBy('created_at', 'desc')->first();
        if(!empty($amountInfo->amount)) {
            $amount = $amountInfo->amount;
        } else {
            $amount = 0;
        }
        return $amount;
    }

    /**
     * 用户订单支出
     * @param  [type] $member_id [description]
     * @param  [type] $payid     [description]
     * @return [type]            [description]
     */
    public function payout($member_id, $payid) {
        $mOrder = new AgentOrderForm();
        $order = $mOrder->find($payid);
        $amount = $this->amount($member_id);

        if(!empty($order) && $order->status == AgentOrderForm::STATUS_NOT_PAY) {
            if($amount < $order->pay_amount) {
                throw new \Exception('余额不足');
            }
            $data = [
                'agent_user_id' => $member_id,
                'amount_pay' => 0 - abs($order->pay_amount),
                'amount' => $amount - abs($order->pay_amount),
                'remark' => '订单支出',
            ];
            $this->create($data);
            //修改用户的余额
            $mMember = new AgentUser();
            $member = $mMember->find($member_id);
            $member->money = $amount - abs($order->pay_amount);
            $member->save();
        }
    }
}
