<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AgentCommodity extends BaseModel
{
    //
    const STATUS_DEFAULT = 1; //正常
    const STATUS_FORBIDEN = 0; //禁用

    const AUCTION_TRUE = 1; //可拍
    const AUCTION_FALSE = 0; //不可拍

    

    public function pictures() {
        return $this->hasMany('App\Models\AgentCommodityPicture', 'agent_commodity_id');
    }
}
