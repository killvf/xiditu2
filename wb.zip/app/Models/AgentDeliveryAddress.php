<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AgentDeliveryAddress extends BaseModel
{
    
    const DEFAULT_TRUE = 1; //默认地址
    const DEFAULT_FALSE = 0; //不是默认地址

    public $timestamps = false; //关闭时间维护

    public $guarded = ['from'];

    /**
     * 把地址设置为默认地址
     *
     * @param [type] $id
     * @return void
     */
    public function setDefault($id) 
    {
        $address = $this->find($id);
        if(!empty($address)) {
            if($address->default == self::DEFAULT_FALSE) {
                $address->default = self::DEFAULT_TRUE;
                $address->save();
            }
            return true;
        }
        return false;
    }

    public function cancelDefault($member_id) {
        $this->where('agent_user_id', $member_id)->update(['default'=>self::DEFAULT_FALSE]);
    }
}
