<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AgentOrderForm extends BaseModel
{
    //

    const STATUS_NOT_PAY = 0; //未支付
    const STATUS_WAIT_POST = 1; //待发货
    const STATUS_WAIT_RECEIVE = 2; //待收货
    const STATUS_FINISHED = 3; //已完成
    const STATUS_WATI_CHECK = 4; //待审核

    const TYPE_LOCAL = 1; //线下支付 
    const TYPE_MONEY = 2;  //余额支付

    public function orders() {
        return $this->hasMany('App\Models\AgentOrderDetail','agent_order_form_id');
    }
}
