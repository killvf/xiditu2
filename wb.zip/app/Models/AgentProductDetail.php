<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AgentProductDetail extends BaseModel
{
    //
    public $timestamps = false;
}
