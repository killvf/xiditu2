<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAgentUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('agent_users', function (Blueprint $table) {
            $table->increments('id');
            $table->string('agent_code'); //编码
            $table->string('username'); //用户名
            $table->char('password', 32); //密码
            $table->string('realname')->default(''); //真实名称
            $table->string('identify_code')->default(''); //身份证
            $table->string('mobile')->default(''); //手机号
            $table->integer('money')->default(0); //钱
            $table->string('ali_account')->default(''); //支付宝账号
            $table->string('wechat_account')->default('');
            $table->tinyInteger('status')->default(1); //默认状态正常
            $table->tinyInteger('is_partner')->default(0); //默认不是合伙人
            $table->timestamps();
            $table->string('remark')->default('');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('agent_users');
    }
}
