<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAgentOrderDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('agent_order_details', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('agent_order_form_id'); // 订单表ID
            $table->integer('agent_commodity_id'); //商品表ID
            $table->string('goods_name'); //商品名
            $table->string('goods_amount'); //购买数量
            $table->integer('price'); //价格 单位分
            $table->integer('unit_price'); //单价
            $table->string('picture'); //图片
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('agent_order_details');
    }
}
