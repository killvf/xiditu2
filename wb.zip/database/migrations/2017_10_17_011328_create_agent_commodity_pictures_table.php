<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAgentCommodityPicturesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('agent_commodity_pictures', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('agent_commodity_id'); //商品ID
            $table->string('title'); //图片标题
            $table->string('url'); //图片地址
            $table->integer('position')->default(0); //图片位置
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('agent_commodity_pictures');
    }
}
