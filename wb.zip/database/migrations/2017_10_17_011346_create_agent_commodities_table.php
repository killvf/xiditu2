<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAgentCommoditiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('agent_commodities', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name'); //商品名
            $table->string('title')->default(''); //商品信息
            $table->integer('unit_price'); // 单价，单位分
            $table->string('brand')->default(''); //品牌
            $table->string('weight')->default(''); //净含量
            $table->text('description'); //商品详情
            $table->tinyInteger('status')->default(0); //状态
            $table->string('onsale_time')->default(''); //上市时间
            $table->tinyInteger('can_auction')->default(0); //是否可拍
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('agent_commodities');
    }
}
