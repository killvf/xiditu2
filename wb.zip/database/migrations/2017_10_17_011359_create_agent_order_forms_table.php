<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAgentOrderFormsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('agent_order_forms', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('submiter_id'); // 下单人ID
            $table->string('order_code'); //订单编号 
            $table->integer('order_sum'); //订单总金额
            $table->integer('goods_sum'); //商品总金额
            $table->integer('goods_amount'); //商品总数
            $table->integer('pay_amount'); //支付总金额 
            $table->string('pay_type')->default(''); //支付方式
            $table->string('account_type')->default(''); //账号类型
            $table->string('pay_account')->default(''); // 支付账号
            $table->tinyInteger('status')->default(0); //订单状态
            $table->string('receiver_name')->default(''); //收货人名称
            $table->string('receiver_mobile')->default(''); //收货人手机号
            $table->string('receiver_addr')->default(''); //收货人地址
            $table->string('order_remark')->default(''); //订单备注
            $table->string('backend_remark')->default(''); // 后台备注
            $table->string('operater')->default(''); //操作人
            $table->tinyInteger('operate_status')->default(0); //操作状态 
            $table->timestamps();
            $table->string('post_company')->default(''); //快递公司
            $table->string('post_code')->default(''); //快递单号
            $table->string('post_remark')->default(''); //快递备注
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('agent_order_forms');
    }
}
