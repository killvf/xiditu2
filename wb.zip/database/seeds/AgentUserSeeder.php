<?php

use Illuminate\Database\Seeder;

class AgentUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $mAgentUser = new \App\Models\AgentUser();
        $mAgentUser->create([
            'agent_code' => '2333',
            'username' => 'root',
            'password' => md5('rootroot'),
        ]);
    }
}
