<?php

use Illuminate\Database\Seeder;

class StaffSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $staff = new \App\Models\Staff();
        $staff->name = 'root';
        $staff->password = md5('rootroot');
        $staff->is_partner = \App\Models\AgentUser::PARTNER_TRUE;
        $staff->save();

    }
}
