/**
 * 得到购物车物品数量
 */
function recalc_shopcart_count() {
    var shopcart = $.cookie('shopcart'),
        count=0;
    if(shopcart) {
        shopcart = JSON.parse(shopcart);
        count = Object.getOwnPropertyNames(shopcart).length;
    }
    return count;
}