@extends('layout.admin.layout')
@section('content')

    index
    @endsection