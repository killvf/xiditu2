@extends('layout.index.index')


@section('content')
    <script type="text/javascript">
        function showImg( url ) {
            var frameid = 'frameimg' + Math.random();
            window.img = '<img id="img" src=\''+url+'\' /><script>window.onload = function() {document.getElementById(\'img\').style.height=\'185px\';document.getElementById(\'img\').style.width=\'139px\'; parent.document.getElementById(\''+frameid+'\').height = document.getElementById(\'img\').height+16+\'px\'; parent.document.getElementById(\''+frameid+'\').width = document.getElementById(\'img\').width + 16 +\'px\'; }<'+'/script>';
            document.write('<iframe id="'+frameid+'" src="javascript:parent.img;" frameBorder="0" scrolling="no" ></iframe>');
        }
    </script>
    <div class="am-container container-fix">

        <div class="am-u-md-12">

            <div class="am-g book-list clear am-text-sm am-text-center am-text-truncate" style="padding-bottom: 10px;">
                @foreach($movies as $movie)
                    <div class="am-u-sm-6 am-u-md-2">
                        <p><a href="{{route('index.play',['url'=>$movie->link])}}" target="_blank">
                                <script>showImg('{{$movie->picture}}')</script>
{{--                                <img src="{{route('snippets.image', ['url'=>$movie->picture])}}" style="width:139px;height:185px;" alt="{{$movie->name}}">--}}
                            </a>
                        </p>
                        <p><a href="{{route('index.play',['url'=>$movie->link])}}"
                              target="_blank">{{$movie->name}}</a></p>
                        {{--<p>{{$movie->desc}}&nbsp;</p>--}}

                    </div>
                @endforeach
            </div>
            <div class="am-text-xs">
                {{$movies->links('vendor.pagination.amaze')}}
            </div>

        </div>
    </div>

@endsection