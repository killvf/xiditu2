<div style="height: 55px;"></div>
<div data-am-widget="navbar" class="am-navbar am-cf am-navbar-default sq-foot am-no-layout" id="">
        <ul class="am-navbar-nav am-cf am-avg-sm-4">
            <li>
                <a href="{{url('/')}}"
                    @if($controller == 'index')
                        class="curr"
                    @endif>
                    <span class="am-icon-home"></span>
                    <span class="am-navbar-label">首页</span>
                </a>
            </li>
            {{--<li>--}}
                {{--<a href="javascript:;" class="">--}}
                    {{--<span class="am-icon-th-large"></span>--}}
                    {{--<span class="am-navbar-label">分类</span>--}}
                {{--</a>--}}
            {{--</li>--}}

            <li>
                <a href="{{route('member.cart.index')}}"
                @if($controller == 'cart')
                class="curr"
                @endif
                >
                    <span class="am-icon-shopping-cart"></span>
                    <span class="am-navbar-label">购物车</span>
                </a>
            </li>
            <li>
                <a href="{{route('member.index')}}"
                    @if($controller == 'member')
                    class="curr"
                    @endif>
                    <span class="am-icon-user"></span>
                    <span class="am-navbar-label">我的</span>
                </a>
            </li>
        </ul>
    </div>