<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>代理商系统</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="icon" type="image/png" href="{{asset('/theme/default/images/favicon.png')}}">
    <link href="{{asset('theme/css/amazeui.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('theme/css/style.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('theme/css/font-awesome.min.css')}}" rel="stylesheet" type="text/css" />
    <script src="{{asset('theme/js/jquery-1.10.2.min.js')}}"></script>
    @yield('style')
</head>
<body>
    @yield('content')

    <script src="{{asset('theme/js/amazeui.min.js')}}"></script>
    
    @yield('script')
    <script src="{{asset('theme/js/app.js')}}"></script>
</body>
</html>
