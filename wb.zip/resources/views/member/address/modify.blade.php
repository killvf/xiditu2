@extends('layout.index.index')


@section('content')
    <header data-am-widget="header" class="am-header am-header-default sq-head ">
        <div class="am-header-left am-header-nav">
            <a href="javascript:history.back()" class="">
                <i class="am-icon-chevron-left"></i>
            </a>
        </div>
        <h1 class="am-header-title">
            <a href="" class="">修改收货地址</a>
        </h1>
    </header>
    <div style="height: 49px;"></div>
    <form action="{{route('member.address.modify.do', ['id'=>$data->id])}}" method="POST">
        @include('member.address.form')
    </form>
    @if(!empty($errors->all()))
        @foreach($errors->all() as $message)
            <div class="am-alert am-alert-danger">
                {{$message}}
            </div>
        @endforeach
    @endif

@endsection

@section('script')

    <script src="{{asset('theme/js/distpicker.data.js')}}"></script>
    <script src="{{asset('theme/js/distpicker.js')}}"></script>
    <script>

        $(function() {
            $("#distpicker").distpicker({
                province: "{{$data->province}}",
                city: "{{$data->city}}",
                district: "{{$data->district}}"
            });
        });

    </script>

@endsection