@extends('layout.index.index')

@section('content')

<header data-am-widget="header" class="am-header am-header-default sq-head ">
        <div class="am-header-left am-header-nav">
            <a href="{{route('member.index')}}" class="">
                <i class="am-icon-chevron-left"></i>
            </a>
        </div>
        <h1 class="am-header-title">
            <a href="{{route('member.order.index')}}" class="">全部订单</a>
        </h1>
    </header>
    <div style="height: 49px;"></div>

    <ul class="order-style">
        <li @if(!isset($_GET['status']))
            class="current"
            @endif><a href="{{route('member.order.index')}}">全部</a></li>
        <li @if(isset($_GET['status']) && $_GET['status'] == 0)
            class="current"
            @endif
        ><a href="{{route('member.order.index', ['status'=> 0])}}">待付款</a></li>
        <li @if(isset($_GET['status']) && $_GET['status'] == 1)
                        class="current"
                        @endif><a href="{{route('member.order.index', ['status'=> 1])}}">待发货</a></li>
        <li @if(isset($_GET['status']) && $_GET['status'] == 2)
                        class="current"
                        @endif><a href="{{route('member.order.index', ['status'=> 2])}}">待收货</a></li>
        <li @if(isset($_GET['status']) && $_GET['status'] == 3)
                        class="current"
                        @endif><a href="{{route('member.order.index', ['status'=> 3])}}">已完成</a></li>
    </ul>
    <!--代付款-->
    @foreach($orders as $order)
    <a href="" style="color: #000;">
        <div class="c-comment">
            <span class="c-comment-num">订单编号：{{$order->order_code}}</span>
            <span class="c-comment-suc">
                @if($order->status == \App\Models\AgentOrderForm::STATUS_NOT_PAY)
                    未付款
                @elseif($order->status == \App\Models\AgentOrderForm::STATUS_WATI_CHECK)
                    待审核
                @elseif($order->status == \App\Models\AgentOrderForm::STATUS_WAIT_POST)
                    待发货
                @elseif($order->status == \App\Models\AgentOrderForm::STATUS_WAIT_RECEIVE)
                    待收货
                @elseif($order->status == \App\Models\AgentOrderForm::STATUS_FINISHED)
                    已完成
                @endif
            </span>
        </div>

        <div class="c-comment-list" style="border: 0;">
            @if(!empty($order->orders))
        @foreach($order->orders as $g)
            <div class="o-con">
                <div class="o-con-img">
                    <img src="{{empty($g->picture) ? '': asset($g->picture)}}">
                </div>
                <div class="o-con-txt">
                    <p>{{$g->goods_name}}</p>
                    <span class="price-t">￥{{$g->unit_price/100}}</span>
                </div>
                <div class="o-con-much"> <h4>x{{$g->goods_amount}}</h4></div>
            </div>
            @endforeach
            @endif
            <div class="c-com-money">共{{$order->goods_amount}}个商品 实付金额：<span>￥ {{$order->order_sum/100}}</span></div>
        </div>
    </a>
    <div class="c-com-btn">
        @if($order->status == \App\Models\AgentOrderForm::STATUS_NOT_PAY)
            <a class="pay" href="{{route('member.order.pay', ['pid' => $order->id])}}">立即支付</a>
            <a class="other cancel" href="javascript:;" data-href="{{route('member.order.cancel', ['id' => $order->id])}}">取消订单</a>
        @elseif($order->status == \App\Models\AgentOrderForm::STATUS_WAIT_POST || $order->status == \App\Models\AgentOrderForm::STATUS_WAIT_RECEIVE)
            <a class="pay receive" href="javascript:;" data-href="{{route('member.order.receive', ['id' => $order->id])}}">确认收货</a>
        @endif

    </div>
    <div class="clear"></div>
    @endforeach

@endsection

@section('script')

    <script>
        $(function() {
            /**
             * 取消订单
             */
            $('.cancel').on('click', function() {
                if(confirm('你确定要取消订单吗')) {
                    location.href = $(this).data('href');
                }
            });

            /**
             * 确认收货
             */
            $('.receive').on('click', function() {
                if(confirm('你确定要确认收货吗')) {
                    location.href = $(this).data('href');
                }
            });
        });
    </script>

    @endsection