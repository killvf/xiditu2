<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::group(['namespace'=>'Index'], function () {
    Route::get('/', 'IndexController@index');

    Route::get('goods/{id}', 'GoodsController@index')->name('index.goods.detail');
 
    //用户前端登录
    Route::any('login', 'LoginController@login')->name('member.login');
    Route::get('hmac', 'LoginController@hmac')->name('member.hmac');
    Route::get('logout', 'LoginController@logout')->name('member.logout');

     //图片上传
     Route::post('upload_pic', 'UploadController@index')->name('upload');
     Route::get('del_pic', 'UploadController@delete')->name('delpic');
});

Route::group(['namespace'=>'Api', 'prefix'=>'api'], function () {
    Route::get('config', 'ConfigController@index');
});

//用户模块
Route::group(['namespace'=>'Member', 'prefix'=>'member', 'middleware'=>'memberAuth'], function () {
    //用户中心首页
    Route::get('/', 'MemberController@index')->name('member.index');
    //修改密码
    Route::any('password/modify', 'MemberController@password')->name('member.password.modify');

    //地址管理
    Route::get('address/add', 'AddressController@add')->name('member.address.add');
    Route::post('address/add', 'AddressController@doAdd')->name('member.address.add.do');
    Route::get('address/delete', 'AddressController@delete')->name('member.address.delete');
    Route::get('address/modify/{id}', 'AddressController@modify')->name('member.address.modify');
    Route::post('address/modify/{id}', 'AddressController@doModify')->name('member.address.modify.do');
    Route::get('addresses', 'AddressController@lists')->name('member.address.index');
    Route::get('address/choose', 'AddressController@choose')->name('member.address.choose');

    //购物车
    Route::get('carts', 'CartController@index')->name('member.cart.index');
    //购买下单页面
    Route::any('order/pay', 'OrderController@pay')->name('member.order.pay');

    //购买确认下单页面
    Route::get('order/sure', 'OrderController@sure')->name('member.order.sure');

    //用户订单页面
    Route::get('orders', 'OrderController@index')->name('member.order.index');

    //用户订单详情页面
    Route::get('order/{id}', 'OrderController@detail')->name('member.order.detail');
    Route::get('order/cancel/{id}', 'OrderController@cancel')->name('member.order.cancel');
    Route::get('order/receive/{id}', 'OrderController@receive')->name('member.order.receive');

});



Route::group(['namespace' => 'Admin', 'prefix'=>'admin'], function () {

    Route::any('login', 'LoginController@login')->name('staff.login');
    Route::get('hmac', 'LoginController@hmac')->name('staff.hmac');
    Route::get('logout', 'LoginController@logout')->name('staff.logout');

    //管理员
    Route::group(['middleware'=>'staffAuth'], function () {
        //主页面
        Route::get('/index', 'IndexController@index')->name('staff.index');

        //管理员管理
        Route::get('agent/modify/{id}', 'AgentUserController@modify')->name('staff.agent.modify');
        Route::post('agent/modify/{id}', 'AgentUserController@doModify')->name('staff.agent.modify.do');
        Route::get('agent', 'AgentUserController@lists')->name('staff.agent.lists');
        Route::get('agent/add', 'AgentUserController@add')->name('staff.agent.add');
        Route::post('agent/add', 'AgentUserController@doAdd')->name('staff.agent.add.do');
        Route::post('agent/delete', 'AgentUserController@delete')->name('staff.agent.delete');
        Route::post('agent/charge', 'AgentUserController@charge')->name('staff.agent.charge');
        Route::post('agent/charge/order', 'AgentUserController@chargeOrder')->name('staff.agent.charge.order');

         //商品管理
         Route::get('commodity/modify/{id}', 'CommodityController@modify')->name('staff.commodity.modify');
         Route::post('commodity/modify/{id}', 'CommodityController@doModify')->name('staff.commodity.modify.do');
         Route::get('commodity', 'CommodityController@lists')->name('staff.commodity.lists');
         Route::get('commodity/add', 'CommodityController@add')->name('staff.commodity.add');
         Route::post('commodity/add', 'CommodityController@doAdd')->name('staff.commodity.add.do');
         Route::post('commodity/delete', 'CommodityController@delete')->name('staff.commodity.delete');

         //订单管理
         Route::get('order/modify/{id}', 'OrderController@modify')->name('staff.order.modify');
         Route::post('order/modify/{id}', 'OrderController@doModify')->name('staff.order.modify.do');
         Route::get('order', 'OrderController@lists')->name('staff.order.lists');
         Route::get('order/add', 'OrderController@add')->name('staff.order.add');
         Route::post('order/add', 'OrderController@doAdd')->name('staff.order.add.do');
         Route::post('order/delete', 'OrderController@delete')->name('staff.order.delete');

        //设置发货信息
        Route::any('order/post/{id}', 'OrderController@post')->name('staff.order.post');
        //审核订单
        Route::get('order/check/{id}', 'OrderController@check')->name('staff.order.check');
    });
});
