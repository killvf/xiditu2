<?php $__env->startSection('content'); ?>

 <!--图片轮换-->
    <div class="am-slider am-slider-default" data-am-flexslider id="demo-slider-0" style="position: relative;">
        <header data-am-widget="header" class="am-header am-header-default tm-head" id="shortbar">
            
            
        </header>
        <ul class="am-slides">
            <li><img src="<?php echo e(asset('theme/images/banner1.png')); ?>" /></li>
            <li><img src="<?php echo e(asset('theme/images/banner.png')); ?>" /></li>
        </ul>
    </div>
    <ul class="shopcart-list">
        <?php $__currentLoopData = $goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(route('index.goods.detail', ['id'=>$g->id])); ?>"><img src="<?php echo e(empty($g->pictures) ? '': $g->pictures[0]->url); ?>" class="shop-pic"></a>
            <div class="shop-list-mid">
                <div class="tit">
                    <a href="<?php echo e(route('index.goods.detail', ['id'=>$g->id])); ?>"><?php echo e($g->name .' '. $g->title); ?></a>
                   <span class="span-price">￥<?php echo e($g->unit_price / 100); ?></span> 
                </div>
            </div>
            <div class="cart">
          
            <a href="javascript:;" class="am-icon-shopping-cart" onclick="add_to_cart('<?php echo e($g->id); ?>')"></a></div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <!--底部-->
    <div style="height: 55px;"></div>
    <?php echo $__env->make('index.snippets.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('theme/js/time.js')); ?>"></script>
<script src="<?php echo e(asset('theme/js/jquery.cookie.js')); ?>"></script>
    <script>
        $(function () {
            var elm = $('#shortbar');
            var startPos = $(elm).offset().top;
            $.event.add(window, "scroll", function () {
                var p = $(window).scrollTop();
                if (p > startPos) {
                    elm.addClass('sortbar-fixed');
                } else {
                    elm.removeClass('sortbar-fixed');
                }
            });
        });

        //添加到购物车
        function add_to_cart(id) {
            var key ='shopcart',
                ids = $.cookie(key);
        
            if(ids) {
                ids = JSON.parse(ids);
            } else {
                ids = {};
            }
            //判断 是否已经添加过
            if(ids.hasOwnProperty(id)) {
                ids[id] += 1;
            } else {
                ids[id] = 1;
            }
    
            $.cookie(key, JSON.stringify(ids));
        }

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>