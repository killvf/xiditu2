<?php $__env->startSection('content'); ?>
    <!-- Page content -->
    <div id="page-content">
        <!-- Validation Header -->
        <div class="content-header">
            <div class="row">
                <div class="col-sm-6">
                    <div class="header-section">
                        <h1>商品管理</h1>
                    </div>
                </div>
                <div class="col-sm-6 hidden-xs">
                    <div class="header-section">
                        <ul class="breadcrumb breadcrumb-top">
                            <li><a href="<?php echo e(route('staff.commodity.lists')); ?>">商品列表</a></li>
                            <li><a href="<?php echo e(route('staff.commodity.add')); ?>">添加商品</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- END Validation Header -->

        <!-- Form Validation Content -->
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <!-- Form Validation Block -->
                <div class="block">
                    <!-- Form Validation Title -->
                    <div class="block-title">
                        <h2>添加商品</h2>
                    </div>
                    <!-- END Form Validation Title -->

                    <!-- Form Validation Form -->
                    <form id="form-validation" action="<?php echo e(route('staff.commodity.add')); ?>" method="post" class="form-horizontal form-bordered">
                        <?php echo $__env->make('admin.commodity.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="form-group form-actions">
                            <div class="col-md-8 col-md-offset-3">
                                <button type="submit" class="btn btn-effect-ripple btn-primary">添加</button>
                                <button type="reset" class="btn btn-effect-ripple btn-danger">重置</button>
                            </div>
                        </div>
                    </form>
                    <!-- END Form Validation Form -->
                </div>
                <!-- END Form Validation Block -->
            </div>
        </div>
        <!-- END Form Validation Content -->
    </div>
    <!-- END Page Content -->

    <?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>