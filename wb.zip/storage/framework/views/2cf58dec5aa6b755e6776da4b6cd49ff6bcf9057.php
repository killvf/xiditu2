<?php $__env->startSection('content'); ?>

    <div class="content-header">
        <div class="row">
            <div class="col-sm-6">
                <div class="header-section">
                    <h1>管理</h1>
                </div>
            </div>
            <div class="col-sm-6 hidden-xs">
                <div class="header-section">
                    <ul class="breadcrumb breadcrumb-top">
                        <li>订单管理</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>


    <!-- Table Styles Block -->
    <div class="block">
        <!-- Table Styles Title -->
        <div class="block-title clearfix">
            <!-- Changing classes functionality initialized in js/pages/tablesGeneral.js -->
            
                
            
            <h2><span >商品列表</span></h2>
        </div>
        <!-- Table Styles Content -->
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-vcenter">
                <thead>
                <tr>
                    <th class="hidden-sm hidden-xs">id</th>
                    <th class="">商品信息</th>
                    <th class="hidden-sm hidden-xs">收货人</th>
                    <th class="hidden-sm hidden-xs">收货人手机</th>
                    <th class="hidden-sm hidden-xs">收货人地址</th>
                    <th class="hidden-sm hidden-xs">订单备注</th>
                    <th class="hidden-sm hidden-xs">快递公司</th>
                    <th class="hidden-sm hidden-xs">快递单号</th>
                    <th style="width: 120px;" class="text-center">
                        <i class="fa fa-flash"></i>
                    </th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="hidden-sm hidden-xs">
                            <a href="javascript:void(0)"
                               class="label label-warning"><?php echo e($goods->id); ?></a></td>
                        <td>
                            <?php if(!empty($goods->orders)): ?>
                                <?php $__currentLoopData = $goods->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($g->goods_name); ?>x<?php echo e($g->goods_amount); ?><br />
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                        <td class="hidden-sm hidden-xs"><?php echo e($goods->receiver_name); ?></td>
                        <td class="hidden-sm hidden-xs"><?php echo e($goods->receiver_mobile); ?></td>
                        <td class="hidden-sm hidden-xs"><?php echo e($goods->receiver_addr); ?></td>
                        <td class="hidden-sm hidden-xs"><?php echo e($goods->order_remark); ?></td>
                        <td class="hidden-sm hidden-xs"><?php echo e($goods->post_company); ?></td>
                        <td class="hidden-sm hidden-xs"><?php echo e($goods->post_code); ?></td>
                        <td class="text-center">
                            <?php if($goods->status == \App\Models\AgentOrderForm::STATUS_NOT_PAY): ?>

                            <?php elseif($goods->status == \App\Models\AgentOrderForm::STATUS_WATI_CHECK): ?>
                                <a href="javascript:;" data-href="<?php echo e(route('staff.order.check', ['id'=>$goods->id])); ?>" data-toggle="tooltip" title="过审"
                                   class="btn btn-effect-ripple btn-xs btn-success check-order"><i class="fa fa-pencil"></i>过审</a>

                            <?php elseif($goods->status == \App\Models\AgentOrderForm::STATUS_WAIT_POST): ?>
                                <a href="<?php echo e(route('staff.order.post', ['id'=>$goods->id])); ?>" data-toggle="tooltip" title="发货"
                                   class="btn btn-effect-ripple btn-xs btn-success"><i class="fa fa-pencil"></i>发货</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($data->links()); ?>

        </div>
        <!-- END Table Styles Content -->
    </div>
    <!-- END Table Styles Block -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>

        $.ajaxSetup({
            headers: { 'X-CSRF-TOKEN' : '<?php echo e(csrf_token()); ?>' }
        });

        $('.check-order').on('click', function () {
            if(confirm('你确定要通过审核吗')) {
                location.href = $(this).data('href');
            }
        });

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>