<?php $__env->startSection('content'); ?>

<header data-am-widget="header" class="am-header am-header-default sq-head ">
        <div class="am-header-left am-header-nav">
            <a href="<?php echo e(route('member.index')); ?>" class="">
                <i class="am-icon-chevron-left"></i>
            </a>
        </div>
        <h1 class="am-header-title">
            <a href="<?php echo e(route('member.order.index')); ?>" class="">全部订单</a>
        </h1>
    </header>
    <div style="height: 49px;"></div>

    <ul class="order-style">
        <li <?php if(!isset($_GET['status'])): ?>
            class="current"
            <?php endif; ?>><a href="<?php echo e(route('member.order.index')); ?>">全部</a></li>
        <li <?php if(isset($_GET['status']) && $_GET['status'] == 0): ?>
            class="current"
            <?php endif; ?>
        ><a href="<?php echo e(route('member.order.index', ['status'=> 0])); ?>">待付款</a></li>
        <li <?php if(isset($_GET['status']) && $_GET['status'] == 1): ?>
                        class="current"
                        <?php endif; ?>><a href="<?php echo e(route('member.order.index', ['status'=> 1])); ?>">待发货</a></li>
        <li <?php if(isset($_GET['status']) && $_GET['status'] == 2): ?>
                        class="current"
                        <?php endif; ?>><a href="<?php echo e(route('member.order.index', ['status'=> 2])); ?>">待收货</a></li>
        <li <?php if(isset($_GET['status']) && $_GET['status'] == 3): ?>
                        class="current"
                        <?php endif; ?>><a href="<?php echo e(route('member.order.index', ['status'=> 3])); ?>">已完成</a></li>
    </ul>
    <!--代付款-->
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="" style="color: #000;">
        <div class="c-comment">
            <span class="c-comment-num">订单编号：<?php echo e($order->order_code); ?></span>
            <span class="c-comment-suc">
                <?php if($order->status == \App\Models\AgentOrderForm::STATUS_NOT_PAY): ?>
                    未付款
                <?php elseif($order->status == \App\Models\AgentOrderForm::STATUS_WATI_CHECK): ?>
                    待审核
                <?php elseif($order->status == \App\Models\AgentOrderForm::STATUS_WAIT_POST): ?>
                    待发货
                <?php elseif($order->status == \App\Models\AgentOrderForm::STATUS_WAIT_RECEIVE): ?>
                    待收货
                <?php elseif($order->status == \App\Models\AgentOrderForm::STATUS_FINISHED): ?>
                    已完成
                <?php endif; ?>
            </span>
        </div>

        <div class="c-comment-list" style="border: 0;">
            <?php if(!empty($order->orders)): ?>
        <?php $__currentLoopData = $order->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="o-con">
                <div class="o-con-img">
                    <img src="<?php echo e(empty($g->picture) ? '': asset($g->picture)); ?>">
                </div>
                <div class="o-con-txt">
                    <p><?php echo e($g->goods_name); ?></p>
                    <span class="price-t">￥<?php echo e($g->unit_price/100); ?></span>
                </div>
                <div class="o-con-much"> <h4>x<?php echo e($g->goods_amount); ?></h4></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <div class="c-com-money">共<?php echo e($order->goods_amount); ?>个商品 实付金额：<span>￥ <?php echo e($order->order_sum/100); ?></span></div>
        </div>
    </a>
    <div class="c-com-btn">
        <?php if($order->status == \App\Models\AgentOrderForm::STATUS_NOT_PAY): ?>
            <a class="pay" href="<?php echo e(route('member.order.pay', ['pid' => $order->id])); ?>">立即支付</a>
            <a class="other cancel" href="javascript:;" data-href="<?php echo e(route('member.order.cancel', ['id' => $order->id])); ?>">取消订单</a>
        <?php elseif($order->status == \App\Models\AgentOrderForm::STATUS_WAIT_POST || $order->status == \App\Models\AgentOrderForm::STATUS_WAIT_RECEIVE): ?>
            <a class="pay receive" href="javascript:;" data-href="<?php echo e(route('member.order.receive', ['id' => $order->id])); ?>">确认收货</a>
        <?php endif; ?>

    </div>
    <div class="clear"></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
        $(function() {
            /**
             * 取消订单
             */
            $('.cancel').on('click', function() {
                if(confirm('你确定要取消订单吗')) {
                    location.href = $(this).data('href');
                }
            });

            /**
             * 确认收货
             */
            $('.receive').on('click', function() {
                if(confirm('你确定要确认收货吗')) {
                    location.href = $(this).data('href');
                }
            });
        });
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>