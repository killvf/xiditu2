<div style="height: 55px;"></div>
<div data-am-widget="navbar" class="am-navbar am-cf am-navbar-default sq-foot am-no-layout" id="">
        <ul class="am-navbar-nav am-cf am-avg-sm-4">
            <li>
                <a href="<?php echo e(url('/')); ?>"
                    <?php if($controller == 'index'): ?>
                        class="curr"
                    <?php endif; ?>>
                    <span class="am-icon-home"></span>
                    <span class="am-navbar-label">首页</span>
                </a>
            </li>
            
                
                    
                    
                
            

            <li>
                <a href="<?php echo e(route('member.cart.index')); ?>"
                <?php if($controller == 'cart'): ?>
                class="curr"
                <?php endif; ?>
                >
                    <span class="am-icon-shopping-cart"></span>
                    <span class="am-navbar-label">购物车</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('member.index')); ?>"
                    <?php if($controller == 'member'): ?>
                    class="curr"
                    <?php endif; ?>>
                    <span class="am-icon-user"></span>
                    <span class="am-navbar-label">我的</span>
                </a>
            </li>
        </ul>
    </div>