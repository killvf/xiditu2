<?php $__env->startSection('content'); ?>

    index
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>