<?php $__env->startSection('content'); ?>
  <!--<header data-am-widget="header" class="am-header am-header-default sq-head ">
        <h1 class="am-header-title">
            <a href="" class="">个人中心</a>
        </h1>
    </header>-->
    <!--<div style="height: 49px;"></div>-->
    <div class="member">
        <div class="mem-tit">
            <?php echo e($member->username); ?>

            
        </div>
        <div class="mem-pic">
            <div class="mem-pic-bg" style="background-image: url(theme/images/memtx.png);"></div>
            <a href="javascript:;" class="men-level">√普通会员</a>
        </div>
        <ul class="member-menu">
            <li>
                <a href="javascript:;">
                    <p class="yellow"><?php echo e($member->money / 100); ?></p>
                    <p class="black">帐户余额 </p>
                </a>
            </li>

            <li>
                <a href="javascript:;">
                    <p class="yellow"><?php echo e(empty($member->product) ? 0 : $member->product->order_amount); ?></p>
                    <p class="black">订单余额</p>
                </a>
            </li>

        </ul>
    </div>
    <div class="user-list">
        <div class="u-list-main">
            <img src="theme/images/order-pic.png" width="27" />
            <span>我的订单</span>
            <a href="<?php echo e(route('member.order.index')); ?>">查看全部订单></a>
        </div>
        <ul class="user-nav">
            <li><a href="<?php echo e(route('member.order.index', ['status'=> 0])); ?>"> <img src="theme/images/icon_topay.png"> <p>待付款</p></a></li>
            <li><a href="<?php echo e(route('member.order.index', ['status'=> 1])); ?>"> <img src="theme/images/icon_tosend.png"> <p>待发货</p></a></li>
            <li><a href="<?php echo e(route('member.order.index', ['status'=> 2])); ?>"> <img src="theme/images/icon_send.png"> <p>待收货</p></a></li>
            <li><a href="<?php echo e(route('member.order.index', ['status'=> 3])); ?>"> <img src="theme/images/icon_sign.png"> <p>已完成</p></a></li>
        </ul>
        <div class="u-list-main">
            <img src="<?php echo e(asset('theme/images/order-my.png')); ?>" width="27" />
            <span>帐户与安全</span>
        </div>
        <ul class="user-nav">
            
            <li><a href="<?php echo e(route('member.address.index')); ?>"> <img src="<?php echo e(asset('theme/images/1-icon5.png')); ?>"> <p>收货地址</p></a></li>
            <li><a href="<?php echo e(route('member.password.modify')); ?>"> <img src="<?php echo e(asset('theme/images/1-icon6.png')); ?>"> <p>修改密码</p></a></li>
            <li><a href=""> <img src="<?php echo e(asset('theme/images/1-icon7.png')); ?>"> <p>我的钱包</p></a></li>
        </ul>
    </div>
    <!--导航-->
    <ul class="sq-nav" style="background:#fff; margin-top:1rem; border-top:1px solid #ddd; border-bottom:1px solid #ddd;">
        
        <li>
            <div class="am-gallery-item">
                <a href="<?php echo e(route('member.logout')); ?>" class="">
                    <img src="<?php echo e(asset('theme/images/icon8.png')); ?>" />
                    <p>安全退出</p>
                </a>
            </div>
        </li>
    </ul>
    <?php echo $__env->make('index.snippets.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.index.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>