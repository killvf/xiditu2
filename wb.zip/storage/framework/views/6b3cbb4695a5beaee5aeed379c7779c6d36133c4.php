<?php $__env->startSection('content'); ?>

    <div class="content-header">
        <div class="row">
            <div class="col-sm-6">
                <div class="header-section">
                    <h1>管理</h1>
                </div>
            </div>
            <div class="col-sm-6 hidden-xs">
                <div class="header-section">
                    <ul class="breadcrumb breadcrumb-top">
                        <li>商品管理</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>


    <!-- Table Styles Block -->
    <div class="block">
        <!-- Table Styles Title -->
        <div class="block-title clearfix">
            <!-- Changing classes functionality initialized in js/pages/tablesGeneral.js -->
            <div class="block-options pull-right">
                <a href="<?php echo e(route('staff.commodity.add')); ?>" class="btn btn-effect-ripple btn-primary">添加</a>
            </div>
            <h2><span >商品列表</span></h2>
        </div>
        <!-- Table Styles Content -->
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-vcenter">
                <thead>
                <tr>
                    <th class="hidden-sm hidden-xs">id</th>
                    <th class="hidden-sm ">商品名</th>
                    <th class="hidden-sm ">商品信息</th>
                    <th class="hidden-sm hidden-xs">商品单价(元)</th>
                    <th class="hidden-sm hidden-xs" >品牌</th>
                    <th class="hidden-sm hidden-xs" >净含量</th>
                    <th class="hidden-sm hidden-xs" >是否可拍</th>
                    <th class="hidden-sm hidden-xs" >上市时间</th>
                    <th style="width: 120px;" class="text-center"><i class="fa fa-flash"></i></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="hidden-sm hidden-xs"><a href="javascript:void(0)"
                                                           class="label label-warning"><?php echo e($goods->id); ?></a></td>
                        <td class="hidden-sm"><?php echo e($goods->name); ?></td>
                        <td class="hidden-sm hidden-xs"><?php echo e($goods->title); ?></td>
                        <td class="hidden-sm hidden-xs"><?php echo e($goods->unit_price / 100); ?></td>
                        <td class="hidden-sm hidden-xs"><?php echo e($goods->brand); ?></td>
                        <td class="hidden-sm hidden-xs"><?php echo e($goods->weight); ?></td>
                        <td class="hidden-sm hidden-xs"><?php echo e($goods->can_auction); ?></td>
                        <td class="hidden-sm hidden-xs"><?php echo e($goods->onsale_time); ?></td>
                        <td class="text-center">
                            <a href="<?php echo e(route('staff.commodity.modify', ['id'=>$goods->id])); ?>" data-toggle="tooltip" title="修改"
                               class="btn btn-effect-ripple btn-xs btn-success"><i class="fa fa-pencil"></i></a>
                            <a href="javascript:;" data-toggle="tooltip" onclick='removeItem("<?php echo e($goods->id); ?>")'
                               title="删除"
                               class="btn btn-effect-ripple btn-xs btn-danger"><i class="fa fa-times"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($data->links()); ?>

        </div>
        <!-- END Table Styles Content -->
    </div>
    <!-- END Table Styles Block -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>


$.ajaxSetup({
    headers: { 'X-CSRF-TOKEN' : '<?php echo e(csrf_token()); ?>' }
});

    //删除指定记录
    function removeItem(id) {
        var target = event.currentTarget;
        if(window.confirm('你确定要删除这条记录吗')) {
            $.ajax({
                url: "<?php echo e(route('staff.commodity.delete')); ?>",
                method: 'POST',
                data: {id: id},
                success: function(data) {
                    if(data.status) {
                        $(target).parents('tr').remove();
                    }
                }, 
                error: function(e) {
                    console.log(e)
                }
            });
        }
    }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>