<?php $__env->startSection('style'); ?>
    <style>


        /*.login-btn {
            height:5rem;
            margin:0;
            width:100%;
        }*/
        .am-ucheck-checkbox:checked+.am-ucheck-icons, .am-ucheck-checkbox:hover:not(.am-nohover):not(:disabled)+.am-ucheck-icons, .am-ucheck-radio:checked+.am-ucheck-icons, .am-ucheck-radio:hover:not(.am-nohover):not(:disabled)+.am-ucheck-icons{
            color:red;
        }

    </style>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <header data-am-widget="header" class="am-header am-header-default sq-head ">
        <div class="am-header-left am-header-nav">
            <a href="javascript:history.back()" class="">
                <i class="am-icon-chevron-left"></i>
            </a>
        </div>
        <h1 class="am-header-title">
            <a href="javascript:;" class="">完成支付</a>
        </h1>
    </header>
    <div style="height: 49px;"></div>
    <ul class="order-subtitle">
        <li><span>订单编号：</span><?php echo e($order->order_code); ?></li>
        <li><span>支付金额：</span><span class="order-money">￥<?php echo e($order->pay_amount / 100); ?></span></li>
    </ul>
    <ul class="order-pay">
        
            
            
                
                
            
            
                
            
        
        
            
            
                
                
            
            
                
            
        
        <li>
            <img src="<?php echo e(asset('theme/images/yuepay.jpg')); ?>" width="50" />
            <span>
                <p>账户余额(<?php echo e($amount / 100); ?>)</p>
                <p class="descript">账户余额支付</p>
            </span>
            <label class="am-radio-inline">
                <input type="radio" name="type" checked="checked" value="<?php echo e(\App\Models\AgentOrderForm::TYPE_MONEY); ?>" data-am-ucheck>
            </label>
        </li>
        <li>
            <img src="<?php echo e(asset('theme/images/yuepay.jpg')); ?>" width="50" />
            <span>
                <p>线下支付</p>
                <p class="descript">账户线下支付</p>
            </span>
            <label class="am-radio-inline">
                <input type="radio" name="type" value="<?php echo e(\App\Models\AgentOrderForm::TYPE_LOCAL); ?>" data-am-ucheck>
            </label>
        </li>

    </ul>

    <div class="order-detail">
        请您在提交订单后24小时内完成付款，否则订单将自动取消
    </div>
    <div style="height: 40px;"></div>
    <input type="button" class="login-btn" data-canorder="<?php echo e(empty(session('member')->product) ? 0 : session('member')->product->order_amount); ?>" data-disabled="<?php echo e($amount < $order->pay_amount ? 1: 0); ?>" <?php if($amount < $order->pay_amount): ?>disabled="disabled"<?php endif; ?> value="确认支付" style="">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('theme/js/jquery.cookie.js')); ?>"></script>
    <script>
        $(function() {
            $.ajaxSetup({
                headers: { 'X-CSRF-TOKEN' : '<?php echo e(csrf_token()); ?>' }
            });
            var payObj = {
                pid: '<?php echo e($order->id); ?>',
                type: '<?php echo e(\App\Models\AgentOrderForm::TYPE_MONEY); ?>',
                canSubmit: '<?php echo e(empty(session('member')->product) ? 0 : (session('member')->product->order_amount > 0 ? ($amount < $order->pay_amount ? 0 : 1) : 0)); ?>'
            };


            $('input[name="type"]').on('change',function() {
                //如果有次数再说下面的事
                if(parseInt($('.login-btn').attr('canorder')) > 0) {
                    if($(this).val() == '<?php echo e(\App\Models\AgentOrderForm::TYPE_LOCAL); ?>') {
                        $('.login-btn').attr('disabled', false);
                        payObj.canSubmit = 0;
                    } else {
                        $('.login-btn').attr('disabled', $('.login-btn').data('disabled') ? 'disabled': false);
                        payObj.canSubmit = parseInt(!$('.login-btn').data('disabled'));
                    }
                }
                //设置支付类型
                payObj.type = $(this).val();
            });

            $('.login-btn').on('click', function() {
                if(payObj.canSubmit > 0) {
                    $.ajax({
                        url: '<?php echo e(route('member.order.pay', ['pid' => $order->id])); ?>',
                        type: 'POST',
                        dataType: 'json',
                        data: payObj,
                        success: function(data) {
                            if(data.status == 1) {
                                alert('支付成功');
                                var buyItems = $.cookie('buyItems'),
                                    shopcarts = $.cookie('shopcart');
                                if(buyItems && shopcarts) {
                                    buyItems = JSON.parse(buyItems);
                                    shopcarts = JSON.parse(shopcarts);
                                    for(item in shopcarts) {
                                        if(buyItems[item]) {
                                            delete shopcarts[item];
                                        }
                                    }
                                    $.cookie('buyItems', '', {path: '/'});
                                    $.cookie('shopcart', JSON.stringify(shopcarts), {path : '/'});
                                }

                                location.href = '<?php echo e(route('member.order.index')); ?>';
                            }
                        },
                        error: function(e){
                            console.log(e);
                        }
                    });
                }

            });

        });
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>