<?php $__env->startSection('content'); ?>

<header data-am-widget="header" class="am-header am-header-default sq-head ">
        <div class="am-header-left am-header-nav">
            <a href="javascript:history.back()" class="">
                <i class="am-icon-chevron-left"></i>
            </a>
        </div>
        <h1 class="am-header-title">
            <a href="" class="">确认订单</a>
        </h1>
    </header>
    <div style="height: 49px;"></div>
    <h5 class="order-tit">收货人信息</h5>
    <?php if(!empty($address)): ?>
    <div class="order-name">
        <a href="<?php echo e(route('member.address.choose')); ?>">
            <p class="order-tele"><?php echo e($address->name); ?>&nbsp;&nbsp;&nbsp;<?php echo e($address->mobile); ?></p>
            <p class="order-add"><?php echo e($address->province.$address->city.$address->district.' '.$address->detail); ?></p>
        </a>
        <i class="am-icon-angle-right"></i>
    </div>
    <?php endif; ?>
    <div class="add-address">
        <a href="<?php echo e(route('member.address.add')); ?>">+新建收货地址</a>
        <i class="am-icon-angle-right"></i>
    </div>
    <div style="background: #eee; height: 10px;"></div>
    <h5 class="order-tit">确认订单信息</h5>
    <ul class="shopcart-list" style="padding-bottom: 0;">
    <?php $__currentLoopData = $goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <img src="<?php echo e(asset(empty($g->pictures) ? '': $g->pictures[0]->url)); ?>" class="shop-pic" />
            <div class="order-mid">
                <div class="tit"><?php echo e($g->name. ' '. $g->title); ?></div>
                <div class="order-price">￥<?php echo e($g->unit_price / 100); ?> <i>X <?php echo e($g->amount); ?></i></div>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <ul class="order-infor">
        <li class="order-infor-first">
            <span>商品总计：</span>
            <i>￥<?php echo e($sum); ?></i>
        </li>
        <li class="order-infor-first">
            <span>运费：</span>
            <i>+ ￥0.00</i>
        </li>
    </ul>
    <div style="background: #eee; height: 10px;"></div>
    <textarea placeholder="备注说明" class="bz-infor"></textarea>
    <div style="background: #eee; height: 10px;"></div>
    <div style="height: 55px;"></div>
    <div class="shop-shoporder">
        <div class="order-text">
            实付：<span>￥<?php echo e($sum); ?></span>
        </div>
        <a href="javascript:;" data-href="<?php echo e(route('member.order.pay')); ?>" class="js-btn">提交订单</a>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
        $(function() {
            $('.js-btn').on('click', function() {
                <?php if($sum <= $amount): ?>
                var remark = $('.bz-infor').val();
                location.href = $(this).data('href') + '?remark=' + remark;
                <?php else: ?>
                    alert('余额不足');
                <?php endif; ?>
            });
        });
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>