<?php $__env->startSection('content'); ?>
<header data-am-widget="header" class="am-header am-header-default sq-head ">
        <div class="am-header-left am-header-nav">
            <a href="<?php echo e(route('member.index')); ?>" class="">
                <i class="am-icon-chevron-left"></i>
            </a>
        </div>
        <h1 class="am-header-title">
            <a href="<?php echo e(route('member.address.index')); ?>" class="">管理收货地址</a>
        </h1>
        <div class="am-header-right am-header-nav">
            <a href="<?php echo e(route('member.address.add', ['from'=>'address'])); ?>" class="">
                <i class="am-icon-plus"></i>
            </a>
        </div>
    </header>
    <div style="height: 49px;"></div>
    <ul class="address-list">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="curr">
            <p>收货人：<?php echo e($d->name); ?>&nbsp;&nbsp;<?php echo e(substr_replace($d->mobile, '****',3, 4)); ?></p>
            <p class="order-add1">收货地址：<?php echo e($d->province.$d->city.$d->district.' '.$d->detail); ?></p>
            <hr />
            <div class="address-cz">
                <label class="am-radio am-warning">
                    <input type="radio" name="radio3" value="" onclick="set_default('<?php echo e(route('member.address.modify', ['id'=>$d->id])); ?>')" data-am-ucheck
                    <?php if($d->default == 1): ?>
                    checked
                    <?php endif; ?>
                    > 设为默认
                </label>
                <a href="<?php echo e(route('member.address.modify', ['id'=>$d->id])); ?>"><i class="icon-pencil icon-large"></i>&nbsp;编辑</a>
                <a href="javascript:;" onclick="del_address('<?php echo e($d->id); ?>')"><i class="icon-trash icon-large"></i>&nbsp;删除</a>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        $.ajaxSetup({
            headers: { 'X-CSRF-TOKEN' : '<?php echo e(csrf_token()); ?>' }
        });
        /**
         * 设为默认地址
         * @param  id
         */
        function set_default(url) {
            $.ajax({
               url: url,
               type: "POST",
               dataType: "json",
               data: {default: 1,agent_user_id: '<?php echo e(session('member')->id); ?>'},
               success: function(data) {
                   if(data.status) {
                       console.log(data);
                   }
               },
                error: function(e) {
                   console.log(e);
                }
            });
        }

        /**
         * 删除地址
         * @param  id
         */
        function del_address(id) {
            var target = event.currentTarget;
            if(window.confirm('你确定要删除地址吗')) {
                $.ajax( {
                    url: "<?php echo e(route('member.address.delete')); ?>",
                    type: "GET",
                    dataType: "json",
                    data: {id: id},
                    success: function(data) {
                        if(data.status) {

                            $(target).parents('li').remove();
                        }
                    },
                    error: function(e) {
                        console.log(e);
                    }
                })
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>