<?php $__env->startSection('content'); ?>
<header data-am-widget="header" class="am-header am-header-default sq-head ">
        <div class="am-header-left am-header-nav">
            <a href="<?php echo e(route("member.index")); ?>" class="">
                <i class="am-icon-chevron-left"></i>
            </a>
        </div>
        <h1 class="am-header-title">
            <a href="<?php echo e(route('member.password.modify')); ?>" class="">修改密码</a>
        </h1>
    </header>
    <div style="height: 49px;"></div>
    <form method="POST" action="<?php echo e(route('member.password.modify')); ?>">
    <?php echo e(csrf_field()); ?>

    <input type="password" name="old_password" placeholder="请输入旧密码" class="login-password">
    <input type="password" name="password" placeholder="请输入密码" class="login-password">
    <input type="password" name="confirm_password" placeholder="确认密码" class="login-password">
    <input type="submit" class="login-btn" value="立即提交">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>