<?php $__env->startSection('content'); ?>
    <header data-am-widget="header" class="am-header am-header-default sq-head ">
        <div class="am-header-left am-header-nav">
            <a href="javascript:history.back()" class="">
                <i class="am-icon-chevron-left"></i>
            </a>
        </div>
        <h1 class="am-header-title">
            <a href="" class="">新增收货地址</a>
        </h1>
    </header>
    <div style="height: 49px;"></div>
    <form action="<?php echo e(route('member.address.add.do')); ?>" method="POST">
    <?php echo $__env->make('member.address.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </form>
    <?php if(!empty($errors->all())): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="am-alert am-alert-danger">
                <?php echo e($message); ?>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(asset('theme/js/distpicker.data.js')); ?>"></script>
    <script src="<?php echo e(asset('theme/js/distpicker.js')); ?>"></script>
    <script>

        $(function() {
            $("#distpicker").distpicker({
                province: "---- 所在省 ----",
                city: "---- 所在市 ----",
                district: "---- 所在区 ----"
            });
        });

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>