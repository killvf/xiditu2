<ul class="sidebar-nav">
    <li>
        <a href="index.html" class=" active"><i class="gi gi-compass sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Dashboard</span></a>
    </li>
    <li class="sidebar-separator">
        <i class="fa fa-ellipsis-h"></i>
    </li>

    <li>
        <a href="<?php echo e(route('staff.commodity.lists')); ?>" <?php if($controller=='admin.commodity'): ?> class="active"<?php endif; ?>>
            <i class="fa fa-rocket sidebar-nav-icon"></i>
            <span class="sidebar-nav-mini-hide">商品管理</span></a>

    </li>
     <li>
        <a href="<?php echo e(route('staff.agent.lists')); ?>" <?php if($controller=='admin.agent'): ?> class="active"<?php endif; ?>>
            <i class="fa fa-rocket sidebar-nav-icon"></i>
            <span class="sidebar-nav-mini-hide">代理商管理</span></a>

    </li>
    <li>
        <a href="<?php echo e(route('staff.order.lists')); ?>" <?php if($controller=='admin.order'): ?> class="active"<?php endif; ?>>
            <i class="fa fa-rocket sidebar-nav-icon"></i>
            <span class="sidebar-nav-mini-hide">订单管理</span></a>

    </li>
    <li class="sidebar-separator">
        <i class="fa fa-ellipsis-h"></i>
    </li>
    

</ul>